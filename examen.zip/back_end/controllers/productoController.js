var producto = require('../schemas/producto');

exports.getproductoSERVER = {
	auth: {
    mode: 'required',
    strategy: 'session',
    scope: ['Admin', 'Regular', 'Rokr']
  },
  handler: function(request, reply){
    var productoS = producto.find({});
    reply(productoS);
  }
}

exports.createproductoSERVER = {
  handler: function(request, reply){

    var newproducto = new producto({

      name : request.payload.name,
      description : request.payload.description,
      ingredient : request.payload.ingredient,
    });
    newproducto.save(function(err){
		if(!err){
			console.log('Nuevo jeugo creado en DB')
        	console.log('The games was replied');
        	return reply('Producto guardado.'); 
		}else{
			console.log('Error encontrado');
        	return reply('Error');
		}

    });
  }
}

exports.modificarproductoSERVER = {
  handler: function(request, reply){
    producto.findOneAndUpdate(
      {name : request.payload.name},
        {description : request.payload.description,
        ingredient: request.payload.ingredient,},
        function(err, productotodos){
      productotodos.save(function(err){
        if(err){
          alert("Not this time!");
        }
      });
    });
  }
}

exports.borrarproductoSERVER = {
  handler: function(request, reply){
    producto.findOneAndRemove(
      {nombre : request.params.nombre}, function(err){
        if(err)
          alert("Nope");
      }
    );
  }
}