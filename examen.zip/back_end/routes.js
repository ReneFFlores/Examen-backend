var productoController = require('./controllers/productoController');
var usersController = require('./controllers/usersController');
var authController = require('./controllers/authController');

exports.endpoints = [{method: 'GET', path: '/', config: {handler: function(request, reply){reply('La cocacola es mala pero aun asi tomo xD')}}},
	{method: 'GET', path: '/v1/producto', config: productoController.getproductoSERVER},
	{method: 'POST', path: '/v2/producto', config: productoController.createproductoSERVER},
    {method: 'DELETE', path: '/v4/producto/{nombre}', config: productoController.borrarproductoSERVER},
	{method: 'POST', path: '/v1/register', config: usersController.createUser},
	{method: 'POST', path: '/v1/login', config: authController.login},
	{method: 'GET', path: '/v1/logout', config: authController.logout}
];
