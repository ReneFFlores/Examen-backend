var mongoose = require('mongoose');

var ProductoSchema = new mongoose.Schema({
  name : String,
  description : String,
  ingredient : String,
});

module.exports = mongoose.model('Producto', ProductoSchema);
